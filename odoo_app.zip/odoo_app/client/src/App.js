import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Skill Swap Platform</h1>
    </div>
  );
}

export default App;